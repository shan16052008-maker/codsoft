---
name: Web-Tech Protocol
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#e7bdb8'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#ad8884'
  outline-variant: '#5d3f3c'
  surface-tint: '#ffb4ac'
  primary: '#ffb4ac'
  on-primary: '#690007'
  primary-container: '#e62429'
  on-primary-container: '#ffffff'
  inverse-primary: '#c00016'
  secondary: '#a5e7ff'
  on-secondary: '#003543'
  secondary-container: '#00d2ff'
  on-secondary-container: '#00566a'
  tertiary: '#ffba38'
  on-tertiary: '#432c00'
  tertiary-container: '#9e6d00'
  on-tertiary-container: '#ffffff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ac'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#93000e'
  secondary-fixed: '#b6ebff'
  secondary-fixed-dim: '#47d6ff'
  on-secondary-fixed: '#001f28'
  on-secondary-fixed-variant: '#004e60'
  tertiary-fixed: '#ffdeac'
  tertiary-fixed-dim: '#ffba38'
  on-tertiary-fixed: '#281900'
  on-tertiary-fixed-variant: '#604100'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Space Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.06em
  label-md:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system synthesizes high-velocity superhero dynamism with advanced Stark Industries defense HUD schematics. Created for hackathons, engineering showcases, and competitive problem-solving platforms, it conveys tactical readiness, high cognitive output, and razor-sharp clarity. 

The aesthetic fuses **Glassmorphic Cyber-HUD** and **Comic-Tech High Contrast**. Interfaces feel like Stark OS heads-up displays running Spidey combat and sensor algorithms: deep obsidian voids, razor-sharp glowing borders, polygonal telemetry badges, and translucent frosted glass containing micro-mesh textures. It treats problem statements not as generic prompts, but as tactical battle directives and classified technical blueprints waiting to be solved.

## Colors

The palette grounds the interface in deep cinematic shadows punctuated by energetic, tactical luminescence:

- **Primary (`#E62429` / `#FF334B`):** Web-slinger crimson. Used for priority action items, urgent alerts, core mission vectors, and focused highlight states.
- **Secondary (`#00D2FF` / `#1E90FF`):** Arc-reactor cyber blue. Used for telemetry metrics, dynamic sensor feedback, glow borders, interactive active links, and secondary interactive states.
- **Tertiary (`#FFB300` / `#F7C844`):** Stark gold. Serves as the high-tier prestige accent for bounties, reward tags, XP indicators, and spotlighted challenges.
- **Backgrounds & Neutral Baselines (`#05070D` & `#0B0F19`):** Carbon black base layers and midnight navy mid-tiers simulate deep outer-hull materials.
- **Surfaces & Overlays:** Low-opacity layers (`rgba(11, 15, 25, 0.75)` and `rgba(18, 26, 44, 0.6)`) with subtle specular web borders (`rgba(0, 210, 255, 0.25)` or `rgba(230, 36, 41, 0.3)`).
- **Text & High Contrast:** `#FFFFFF` for primary titles and technical parameters, `#94A3B8` (slate gray) for body metrics, and `#475569` for auxiliary metadata.

## Typography

The typography couples futuristic aerospace geometry with functional terminal readouts:

- **Headlines (Space Grotesk):** Delivers aerodynamic, sharp-edged hero headings and problem titles reminiscent of next-gen prototype interfaces.
- **Body (Geist):** Provides ultra-clean legibility for problem descriptions, rubric criteria, and tech stack constraints without distracting visual noise.
- **Labels, Telemetry, Badges (Space Mono):** Used in uppercase format for challenge IDs, bounty tags, timestamps, and difficulty indicators, driving home the classified terminal aesthetic.

## Layout & Spacing

This design system uses a strict 12-column dynamic fluid grid for desktop (`min-width: 1024px`), transitioning to an 8-column layout on tablet (`768px - 1023px`), and a 4-column stack on mobile screens (`< 768px`).

- **Grid Alignment:** Cards and HUD panels snap to an 8px modular baseline. Grid gaps remain wide enough (`1.5rem`) to allow luminous border blooms to project without overlapping neighboring interactive targets.
- **Density:** High visual density across data rows, contrasting with ample section spacing (`space-xl` and generous page margins) to establish cinematic breathing room between tracks, live stats, and problem sets.

## Elevation & Depth

Visual hierarchy abandons traditional muddy drop shadows in favor of **Arc Glassmorphism** and **Chroma Glows**:

- **Ground Level (Background):** Void `#05070D` with an engineered SVG background pattern featuring an ultra-faint spider-web wireframe combined with diagonal HUD crosshairs at 4% opacity.
- **Surface Layer 1 (HUD Deck):** Translucent `#0B0F19` at 70% opacity, paired with `backdrop-filter: blur(12px)` and a crisp 1px perimeter line of `rgba(0, 210, 255, 0.15)`.
- **Surface Layer 2 (Active Cards & Modals):** Semi-opaque `#121A2C` at 85% opacity, `backdrop-filter: blur(20px)`, framed with a dual border: a 1px solid stroke (`rgba(230, 36, 41, 0.4)`) and a diffuse atmospheric drop-glow (`0 0 24px rgba(230, 36, 41, 0.18)`).
- **Interactive State Elevation:** On hover, surfaces brighten, the border stroke transitions to pure cyber blue (`#00D2FF`) or web crimson (`#FF334B`), and the ambient glow intensity escalates with a zero-delay transition for an immediate heads-up reaction.

## Shapes

The design language favors clipped, precision-engineered geometric structures over bubbly consumer shapes:

- **Soft Clipped Geometry (`roundedness: 1`):** Micro-radii (4px to 8px) provide structure without looking blunt. 
- **Chamfered & Angled Accents:** Cards and badges utilize subtle 45-degree corner notches (chamfer clips) on opposing diagonal corners (top-right, bottom-left) to simulate armored plating and Stark tech chassis.
- **Divider Accents:** Data dividers leverage high-tech hairline guides with diamond or crosshair node terminals.

## Components

### Buttons
- **Primary ("Web-Strike"):** Solid Crimson (`#E62429`), crisp Stark White text in `Space Mono`, uppercase with slight letter spacing. Angled or soft-chamfered corners. On hover, background shifts to `#FF334B` with an intense crimson aura (`box-shadow: 0 0 16px rgba(230, 36, 41, 0.6)`).
- **Secondary ("Stark Arc"):** Frosted glass surface, 1px cyber blue outline (`#00D2FF`), cyber blue text. Hover fills the background with `rgba(0, 210, 255, 0.15)` and produces an energetic arc glow.
- **Tertiary / Action Badges:** Stark Gold (`#FFB300`) border and icon, suited for challenge submissions and prize pool tracking.

### Problem Statement HUD Cards
- Composed of translucent midnight panels with backdrop blurs.
- Features a comic-tech track badge at the top-left (e.g., `[SYS.AI // SPIDER-SENSE]`) and a Stark difficulty rating badge at the top-right.
- Hover produces a subtle holographic web-mesh pattern illumination across the card's interior background and an amplified exterior glow.

### Chips & Badges
- **Comic-Tech Badges:** Monospace typography with angled edge styling and high-contrast background pills (`rgba(230, 36, 41, 0.15)` for Spider-Core, `rgba(255, 179, 0, 0.15)` for Gold Bounties, `rgba(0, 210, 255, 0.15)` for Cyber tracks). 
- Always accompanied by an inset 1px luminous rim.

### Input Fields & Search Bars
- Dark tactical chassis (`#0B0F19`) with 1px muted slate borders (`#334155`).
- Monospace placeholder text (`SEARCH PROBLEM MATRIX...`).
- When focused, the border ignites in cyber blue (`#00D2FF`) with an interior faint light gradient and an external 8px glow.

### Checkboxes, Radios, & Filters
- Geometric square checkboxes with diamond checks; selected state fills with crimson (`#E62429`) and a sharp white glyph.
- Radio buttons feature concentric arc-reactor rings that lock into electric cyan (`#00D2FF`) when active.

### Lists & Matrix Tables
- Alternating dark translucent rows bounded by subtle horizontal web-wire lines.
- Hovering over a problem statement row triggers an electric blue indicator bracket on the left edge.